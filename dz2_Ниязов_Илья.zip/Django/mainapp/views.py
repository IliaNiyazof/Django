from django.shortcuts import render
from django.http import HttpRequest


# def index(request: HttpRequest):
#    users = [
#       {'name': 'John', 'age': 10},
#       {'name': 'Artur', 'age': 20},
#       {'name': 'David', 'age': 30},
#    ]
#    return render(request, 'mainapp/index.html',{
#       'data': users
#    })

def index(request: HttpRequest):
   return render(request, 'mainapp/child.html')

def catalog(request: HttpRequest):
   return render(request, 'mainapp/child1.html')

def contakt(request: HttpRequest):
   return render(request, 'mainapp/child2.html')

def goods1(request: HttpRequest):
   return render(request, 'mainapp/child3.html')